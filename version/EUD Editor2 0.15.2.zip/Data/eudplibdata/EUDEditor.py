from eudplib import *

def onPluginStart():
    DoActions([
       SetMemory(0x66398C, Subtract, 19660800),
       SetMemory(0x66052C, Subtract, 115998720),
       SetMemory(0x657558, Subtract, 288),
       SetMemory(0x6563A0, Subtract, 4915200),
    ])

